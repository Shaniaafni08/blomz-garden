<?php

session_start();
$_SESSION['pesanan'] = NULL;