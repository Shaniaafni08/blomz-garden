<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "blomz_garden"; // ganti sesuai nama database kamu

$conn = mysqli_connect($host, $user, $pass, $db, 3307);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
